# from . import db
# from flask_login import UserMixin

# class Disciplina(db.Model):
#     __tablename__ = 'laura_tbdisciplina'
#     id = db.Column(db.Integer, primary_key=True)
#     nome = db.Column(db.String(256), nullable=False)
#     carga_horaria = db.Column(db.Integer, nullable=False)

# # Modelo para cursos
# class Curso(db.Model):
#     __tablename__ = 'laura_tbcursos'
#     id = db.Column(db.Integer, primary_key=True)
#     nome = db.Column(db.String(50), nullable=False)
#     carga_horaria_total = db.Column(db.Integer, nullable=False, default=0)

#     # Relacionamento com disciplinas
#     disciplinas = db.relationship('Curso_Disciplina', back_populates='curso')

# # Tabela de associação entre cursos e disciplinas
# class Curso_Disciplina(db.Model):
#     __tablename__ = 'laura_tbcursos_disciplinas'
#     cursoId = db.Column(db.Integer, db.ForeignKey('laura_tbcursos.id'), primary_key=True)
#     disciplinaId = db.Column(db.Integer, db.ForeignKey('laura_tbdisciplina.id'), primary_key=True)
    
#     # Relacionamentos
#     curso = db.relationship('Curso', back_populates='disciplinas')
#     disciplina = db.relationship('Disciplina')

# class Aluno(db.Model):
#     __tablename__ = 'laura_tbalunos'
#     id = db.Column(db.Integer, primary_key=True)
#     usuario_login = db.Column(db.String(100), nullable=False, unique=True)
#     nome = db.Column(db.String(50), nullable=False)
#     cpf = db.Column(db.String(14), nullable=False, unique=True)  # Garantir que o CPF seja único
#     senha = db.Column(db.String(100), nullable=False)

#     # Relacionamento 1 para 1 com Endereco
#     endereco_id = db.Column(db.Integer, db.ForeignKey('laura_tbenderecos.id'), unique=True)
#     endereco = db.relationship('Endereco', backref='aluno', uselist=False)  # uselist=False garante que é 1:1

#     # Relacionamento com o curso
#     curso_id = db.Column(db.Integer, db.ForeignKey('laura_tbcursos.id'), nullable=False)
#     curso = db.relationship('Curso', backref='alunos')

# class Endereco(db.Model):
#     __tablename__ = 'laura_tbenderecos'
#     id = db.Column(db.Integer, primary_key=True)
#     rua = db.Column(db.String(256), nullable=False)
#     numero = db.Column(db.Integer, nullable=False)
#     bairro = db.Column(db.String(100), nullable=False)
#     cidade = db.Column(db.String(100), nullable=False)
#     estado = db.Column(db.String(2), nullable=False)
#     cep = db.Column(db.String(10), nullable=False)


# class Professor(db.Model):
#     __tablename__ = 'laura_tbprofessor'
#     id = db.Column(db.Integer, primary_key=True)
#     nome = db.Column(db.String(100), nullable=False)
#     telefone = db.Column(db.String(15), nullable=True)  # Alterei para string para suportar códigos de telefone com DDD
#     usuario_login = db.Column(db.String(100), nullable=False, unique=True)
#     senha = db.Column(db.String(100), nullable=False)

#     # Relacionamento com disciplinas
#     disciplinas = db.relationship('Professor_Disciplina', back_populates='professor')

# class Professor_Disciplina(db.Table):
#     __tablename__ = 'laura_tbprofessor_disciplinas'
#     professor_id = db.Column(db.Integer, db.ForeignKey('laura_tbprofessor.id'), primary_key=True)
#     disciplina_id = db.Column(db.Integer, db.ForeignKey('laura_tbdisciplina.id'), primary_key=True)

#     # Relacionamentos
#     professor = db.relationship('Professor', back_populates='disciplinas')
#     disciplina = db.relationship('Disciplina', backref='professores')
