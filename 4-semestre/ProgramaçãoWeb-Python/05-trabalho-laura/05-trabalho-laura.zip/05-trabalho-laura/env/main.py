from flask import Flask, render_template, request, redirect, url_for, flash
from dotenv import load_dotenv
import mysql.connector
import os

# Carregar variáveis de ambiente do arquivo .env
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
''
# Testando conexão com o banco de dados
try:
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
except:
    print("Ocorreu um erro ao se conectar com o banco de dados.")
if conn and conn.is_connected():
    print("Conexão com o banco de dados estabelecida com sucesso.")
    conn.close()

# Rota Principal
@app.route('/')
def index():
    # Renderiza a página base com links para os cadastros
    return render_template('index.html')


# Cadastro de Disciplinas
@app.route('/disciplinas', methods=['GET', 'POST'])
def disciplinas():
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        nome = request.form['nome']
        carga_horaria = request.form['carga_horaria']
        cursor.execute("INSERT INTO laura_tbdisciplinas (nome, carga_horaria) VALUES (%s, %s)", (nome, carga_horaria))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('disciplinas'))

    cursor.execute("SELECT * FROM laura_tbdisciplinas")
    disciplinas = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('disciplinas.html', disciplinas=disciplinas)


@app.route('/disciplinas/edit/<int:id>', methods=['GET', 'POST'])
def editar_disciplina(id):
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        nome = request.form['nome']
        carga_horaria = request.form['carga_horaria']
        cursor.execute("UPDATE laura_tbdisciplinas SET nome = %s, carga_horaria = %s WHERE id = %s", (nome, carga_horaria, id))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('disciplinas'))

    cursor.execute("SELECT * FROM laura_tbdisciplinas WHERE id = %s", (id,))
    disciplina = cursor.fetchone()
    cursor.close()
    conn.close()
    return render_template('editar_disciplina.html', disciplina=disciplina)

@app.route('/disciplinas/delete/<int:id>', methods=['POST'])
def excluir_disciplina(id):
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor(dictionary=True)

    try:
        # Deleta a disciplina com o ID fornecido
        cursor.execute("DELETE FROM laura_tbdisciplinas WHERE id = %s", (id,))
        conn.commit()
    except Exception as e:
        print(f"Erro ao excluir disciplina: {e}")
        conn.rollback()
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for('disciplinas'))


# Cadastro de Cursos
@app.route('/cursos', methods=['GET', 'POST'])
def cursos():
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor(dictionary=True)

    # Cadastro de novo curso
    if request.method == 'POST':
        nome = request.form['nome']
        disciplinas = request.form.getlist('disciplinas')

        # Inserindo o curso
        cursor.execute("INSERT INTO laura_tbcursos (nome) VALUES (%s)", (nome,))
        curso_id = cursor.lastrowid

        # Relacionando o curso às disciplinas
        for disciplina_id in disciplinas:
            cursor.execute("INSERT INTO laura_tbcursos_disciplinas (curso_id, disciplina_id) VALUES (%s, %s)", (curso_id, disciplina_id))

        conn.commit()

    # Busca as disciplinas para o cadastro
    cursor.execute("SELECT * FROM laura_tbdisciplinas")
    disciplinas = cursor.fetchall()

    # Lista os cursos com carga horária total
    cursor.execute("""
        SELECT 
            cursos.id, 
            cursos.nome, 
            GROUP_CONCAT(disciplinas.nome SEPARATOR ', ') AS disciplinas,
            SUM(disciplinas.carga_horaria) AS carga_horaria_total
        FROM laura_tbcursos AS cursos
        LEFT JOIN laura_tbcursos_disciplinas AS cd ON cursos.id = cd.curso_id
        LEFT JOIN laura_tbdisciplinas AS disciplinas ON cd.disciplina_id = disciplinas.id
        GROUP BY cursos.id
    """)
    cursos = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('cursos.html', cursos=cursos, disciplinas=disciplinas)


@app.route('/cursos/editar/<int:id>', methods=['GET', 'POST'])
def editar_curso(id):
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        nome = request.form['nome']
        disciplinas = request.form.getlist('disciplinas')

        cursor.execute("UPDATE laura_tbcursos SET nome = %s WHERE id = %s", (nome, id))

        cursor.execute("DELETE FROM laura_tbcursos_disciplinas WHERE curso_id = %s", (id,))
        for disciplina_id in disciplinas:
            cursor.execute("INSERT INTO laura_tbcursos_disciplinas (curso_id, disciplina_id) VALUES (%s, %s)", (id, disciplina_id))

        conn.commit()

        return redirect(url_for('cursos'))

    cursor.execute("SELECT * FROM laura_tbdisciplinas")
    disciplinas = cursor.fetchall()

    cursor.execute("""
        SELECT cursos.id, cursos.nome, GROUP_CONCAT(disciplinas.id SEPARATOR ',') AS disciplinas
        FROM laura_tbcursos AS cursos
        LEFT JOIN laura_tbcursos_disciplinas AS cd ON cursos.id = cd.curso_id
        LEFT JOIN laura_tbdisciplinas AS disciplinas ON cd.disciplina_id = disciplinas.id
        WHERE cursos.id = %s
        GROUP BY cursos.id
    """, (id,))
    curso = cursor.fetchone()

    cursor.close()
    conn.close()

    return render_template('editar_curso.html', curso=curso, disciplinas=disciplinas)


# exclusão de curso
@app.route('/cursos/delete/<int:id>', methods=['POST'])
def excluir_curso(id):
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor(dictionary=True)

    try:
        # Exclui os registros relacionados na tabela laura_tbcursos_disciplinas
        cursor.execute("DELETE FROM laura_tbcursos_disciplinas WHERE curso_id = %s", (id,))

        # Exclui o curso pelo ID
        cursor.execute("DELETE FROM laura_tbcursos WHERE id = %s", (id,))
        conn.commit()
    except Exception as e:
        print(f"Erro ao excluir curso: {e}")
        conn.rollback()
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for('cursos'))


# Cadastro de Professores
@app.route('/professores', methods=['GET', 'POST'])
def professores():
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        nome = request.form['nome']
        telefone = request.form['telefone']
        usuario = request.form['usuario']
        senha = request.form['senha']
        disciplinas = request.form.getlist('disciplinas')
        cursor.execute("INSERT INTO laura_tbprofessores (nome, telefone, usuario, senha) VALUES (%s, %s, %s, %s)", 
                       (nome, telefone, usuario, senha))
        professor_id = cursor.lastrowid
        for disciplina_id in disciplinas:
            cursor.execute("INSERT INTO laura_tbprofessores_disciplinas (professor_id, disciplina_id) VALUES (%s, %s)", 
                           (professor_id, disciplina_id))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('professores'))

    cursor.execute("SELECT * FROM laura_tbdisciplinas")
    disciplinas = cursor.fetchall()
    cursor.execute("""
        SELECT professores.id, professores.nome, professores.telefone, GROUP_CONCAT(disciplinas.nome SEPARATOR ', ') AS disciplinas
        FROM laura_tbprofessores AS professores
        LEFT JOIN laura_tbprofessores_disciplinas AS pd ON professores.id = pd.professor_id
        LEFT JOIN laura_tbdisciplinas AS disciplinas ON pd.disciplina_id = disciplinas.id
        GROUP BY professores.id
    """)
    professores = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('professores.html', professores=professores, disciplinas=disciplinas)

# Editar professores
@app.route('/editar_professor/<int:id>', methods=['GET', 'POST'])
def editar_professor(id):
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor(dictionary=True)

    # Carregar o professor para edição
    if request.method == 'GET':
        cursor.execute("SELECT * FROM laura_tbprofessores WHERE id=%s", (id,))
        professor = cursor.fetchone()
        cursor.execute("SELECT * FROM laura_tbdisciplinas")
        disciplinas = cursor.fetchall()
        cursor.execute("""
            SELECT disciplina_id FROM laura_tbprofessores_disciplinas WHERE professor_id=%s
        """, (id,))
        disciplinas_selecionadas = [d['disciplina_id'] for d in cursor.fetchall()]
        cursor.close()
        conn.close()
        return render_template('editar_professor.html', professor=professor, disciplinas=disciplinas, disciplinas_selecionadas=disciplinas_selecionadas)

    # Atualizar o professor
    if request.method == 'POST':
        nome = request.form['nome']
        telefone = request.form['telefone']
        usuario = request.form['usuario']
        senha_atual = request.form['senha_atual']  # Senha atual fornecida pelo usuário
        disciplinas = request.form.getlist('disciplinas')

        # Verificar se a senha atual está correta
        cursor.execute("SELECT senha FROM laura_tbprofessores WHERE id=%s", (id,))
        professor = cursor.fetchone()

        # Se a senha atual fornecida não for a mesma que a do banco de dados, mostrar erro
        if professor and professor['senha'] != senha_atual:
            flash('A senha atual fornecida está incorreta. A edição dos dados foi cancelada.', 'danger')
            return redirect(url_for('editar_professor', id=id))

        # Atualizar dados do professor (não atualizando a senha)
        cursor.execute("UPDATE laura_tbprofessores SET nome=%s, telefone=%s, usuario=%s WHERE id=%s", 
                       (nome, telefone, usuario, id))

        # Atualizar disciplinas associadas
        cursor.execute("DELETE FROM laura_tbprofessores_disciplinas WHERE professor_id=%s", (id,))
        for disciplina_id in disciplinas:
            cursor.execute("INSERT INTO laura_tbprofessores_disciplinas (professor_id, disciplina_id) VALUES (%s, %s)", 
                           (id, disciplina_id))

        conn.commit()
        cursor.close()
        conn.close()
        flash('Professor atualizado com sucesso.', 'success')
        return redirect(url_for('professores'))

# Excluir professor
@app.route('/professores/excluir/<int:id>', methods=['POST'])
def excluir_professor(id):
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor()

    try:
        # Excluir as disciplinas relacionadas ao professor
        cursor.execute("DELETE FROM laura_tbprofessores_disciplinas WHERE professor_id = %s", (id,))
        
        # Excluir o professor
        cursor.execute("DELETE FROM laura_tbprofessores WHERE id = %s", (id,))
        
        conn.commit()
    except Exception as e:
        conn.rollback()
        print(f"Erro ao excluir professor: {e}")
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for('professores'))



# Cadastro de Alunos
@app.route('/alunos', methods=['GET', 'POST'])
def alunos():
    if request.method == 'POST':
        nome = request.form['nome']
        cpf = request.form['cpf']
        endereco = request.form['endereco']
        senha = request.form['senha']
        curso_id = request.form['curso_id']

        # Conexão com o banco de dados
        conn = mysql.connector.connect(
            user='usr_aluno',
            password='E$tud@_m@1$',
            host='201.23.3.86',
            port=5000,
            database='aula_fatec'
        )
        cursor = conn.cursor()

        # Verificar se o CPF já existe
        query = """
            SELECT COUNT(*)
            FROM laura_tbalunos AS alunos
            LEFT JOIN laura_tbcursos AS cursos ON alunos.curso_id = cursos.id
            WHERE alunos.cpf = %s OR EXISTS (
                SELECT 1 FROM laura_tbprofessores WHERE cpf = %s
            )
        """
        cursor.execute(query, (cpf, cpf))
        conta_existe = cursor.fetchone()[0]

        if conta_existe:
            cursor.close()
            conn.close()
            return "Erro: CPF já cadastrado como aluno ou professor!", 400

        # Inserir novo aluno
        try:
            cursor.execute(
                "INSERT INTO laura_tbalunos (nome, cpf, endereco, senha, curso_id) VALUES (%s, %s, %s, %s, %s)",
                (nome, cpf, endereco, senha, curso_id)
            )
            conn.commit()
        except mysql.connector.Error as err:
            conn.rollback()
            cursor.close()
            conn.close()
            return f"Erro ao cadastrar aluno: {err}", 500

        cursor.close()
        conn.close()

        return redirect(url_for('alunos'))

    else:
        # Quando for GET, exibe os dados
        conn = mysql.connector.connect(
            user='usr_aluno',
            password='E$tud@_m@1$',
            host='201.23.3.86',
            port=5000,
            database='aula_fatec'
        )
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM laura_tbcursos")
        cursos = cursor.fetchall()

        cursor.execute("""SELECT alunos.id, alunos.nome, alunos.cpf, alunos.endereco, cursos.nome AS curso
                        FROM laura_tbalunos AS alunos
                        LEFT JOIN laura_tbcursos AS cursos ON alunos.curso_id = cursos.id""")
        alunos = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('alunos.html', cursos=cursos, alunos=alunos)



@app.route('/alunos/editar/<int:id>', methods=['GET', 'POST'])
def editar_aluno(id):
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor(dictionary=True)

    # Recuperar dados do aluno
    cursor.execute("SELECT * FROM laura_tbalunos WHERE id = %s", (id,))
    aluno = cursor.fetchone()

    if not aluno:
        flash('Aluno não encontrado!', 'danger')
        return redirect(url_for('alunos'))

    if request.method == 'POST':
        nome = request.form['nome']
        cpf = request.form['cpf']
        endereco = request.form['endereco']
        senha = request.form['senha']
        curso_id = request.form['curso']
        
        # Verifica se a senha informada está correta
        if senha == aluno['senha']:
            cursor.execute("""
                UPDATE laura_tbalunos
                SET nome = %s, cpf = %s, endereco = %s, senha = %s, curso_id = %s
                WHERE id = %s
            """, (nome, cpf, endereco, senha, curso_id, id))
            conn.commit()
            flash('Aluno atualizado com sucesso!', 'success')
            return redirect(url_for('alunos'))
        else:
            flash('Senha incorreta! Edição cancelada.', 'danger')
            return redirect(url_for('editar_aluno', id=id))

    cursor.execute("SELECT * FROM laura_tbcursos")
    cursos = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('editar_aluno.html', aluno=aluno, cursos=cursos)


# Deletar aluno
@app.route('/alunos/deletar/<int:id>', methods=['POST'])
def excluir_aluno(id):
    conn = mysql.connector.connect(
        user='usr_aluno',
        password='E$tud@_m@1$',
        host='201.23.3.86',
        port=5000,
        database='aula_fatec'
    )
    cursor = conn.cursor()

    try:
        cursor.execute("DELETE FROM laura_tbalunos WHERE id = %s", (id,))
        conn.commit()
    except Exception as e:
        conn.rollback()
        print(f"Erro ao excluir aluno: {e}")
    finally:
        cursor.close()
        conn.close()

    return redirect(url_for('alunos'))



if __name__ == '__main__':
    app.run(debug=True)
