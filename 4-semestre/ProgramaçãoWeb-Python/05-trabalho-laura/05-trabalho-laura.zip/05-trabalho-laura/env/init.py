# #utilizei o init e o models para criar as tabelas, porem só foram usados para isto

# from flask import Flask
# from flask_sqlalchemy import SQLAlchemy
# import urllib.parse

# db = SQLAlchemy()

# def create_app(debug=False):
#     app = Flask(__name__)
    
#     # Configurações do banco de dados
#     user = 'usr_aluno'
#     password = 'E$tud@_m@1$'
#     host = '201.23.3.86'
#     port = '5000'
#     database = 'aula_fatec'
    
#     escaped_password = urllib.parse.quote_plus(password)
#     escaped_user = urllib.parse.quote_plus(user)
    
#     connection_url = f"mysql+mysqlconnector://{escaped_user}:{escaped_password}@{host}:{port}/{database}"
    
#     app.config['SQLALCHEMY_DATABASE_URI'] = connection_url
#     app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
#     db.init_app(app)
    
#     # Criando as tabelas dentro do contexto do aplicativo
#     with app.app_context():
#         try:
#             # Importa os modelos aqui
#             from .models import Disciplina
            
#             # Força a criação da tabela
#             db.create_all()
#             print('Tabelas criadas com sucesso!')
#         except Exception as e:
#             print(f'Erro ao criar as tabelas: {str(e)}')
    
#     return app